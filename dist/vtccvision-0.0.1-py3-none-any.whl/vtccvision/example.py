def test():
    print("test function")
